<div id= "menu">
	<nav>
		<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="peliculas.php">Películas</a></li>
		<li><a href="directores.php">Directores</a></li>
		<li><a href="generos.php">Género</a></li>
		<li><a href="paises.php">Países</a></li>
		
		</ul>
		
		<div class="clear"></div>
	</nav>
	
</div>	