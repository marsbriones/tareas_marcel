
<?php
	
	include_once ("variables.php"); 
	$titulo_pagina = "Películas";
	$peliculas = mysql_query("SELECT * FROM peliculas");
	
?>


<!DOCTYPE HTML>
<html>
<head>

<?php include_once("head.php");?>	

</head>




<body>
	<header>
		<h1><?php echo $titulo_pagina ?></h1>
		<?php include_once ("menu.php");?>
	</header>
    
    

 		<?php
 		while($fila= mysql_fetch_array($peliculas)){
 		 
 		echo "<div class='pelicula'>";
		
		
		
		if ($fila['poster'] == "") {
					echo "<img src='imagenes/peliculas/posters/nodis.jpg'/>";
				}else{
					echo "<img src='imagenes/peliculas/posters/" . $fila['poster'] ."'/>";
				}
		echo "<div class='datopelicula nombrepelicula'>" . $fila['titulo'] . "</div>";
		echo "<div class='datopelicula'>" . $fila['fecha_estreno'] . "</div>";
		echo "<div class='datopelicula'>" . $fila['duracion'] . "min </div>";
		echo "</div>";
 
 		}
 
 		?>
        
<!--echo "<img src='imagenes/peliculas/posters/" . $fila['poster'] . "' />";-->

<div class="clear"></div>
    	
</body>
</html>
