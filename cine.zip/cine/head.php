<meta charset="UTF-8">
<title> <?php echo $titulo_general . "-" . $titulo_pagina ?></title>
<link href='http://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>
 <link href="css/estilo.css" rel="stylesheet" type="text/css" charset="utf-8"s />