<?php
	$titulo_general = "Cine";
	include_once ("conexion.php");
	
	
?>


