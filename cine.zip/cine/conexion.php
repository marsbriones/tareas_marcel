<?php 

//conexion a la base de datos
		$enlace = mysql_connect('localhost', 'root', 'root');
		
		
		
		if (!$enlace){
			die('No se pudo conectar:' . mysql_error());
		}
		
//Dont, not , diferente de, Negativa a la condicional		
//instrucciones de PHP con respecto a MySQL
//mysql_connect
//mysql_select_bd
//mysql_set_charset		
		
		$bd = mysql_select_db('Cine', $enlace);
		mysql_set_charset('utf8', $enlace);
		mysql_query("SET NAMES 'utf8'");
		
		
	?>

