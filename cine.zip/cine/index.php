
<?php
	
	include_once ("variables.php"); 
	$titulo_pagina = "Inicio";
	
?>


<!DOCTYPE HTML>
<html>
<head>
<?php include_once ("head.php"); ?>

</head>



<body>
	<header>
		<h1><?php echo $titulo_general?></h1>
		<?php include_once ("menu.php");?>
	</header>	
		
</body>
</html>
